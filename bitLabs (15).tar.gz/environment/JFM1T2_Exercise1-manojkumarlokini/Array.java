//Array: Array is collection of similar type of elements.


class Example8{
    
    public static void main(String args[]){
      
      int arr[]={23,45,67,78,90,65,33,22};
      
      System.out.println(arr[3]);
      System.out.println(arr[0]);
      
      System.out.println(arr.length);   // to find number of elements in an array.
      
      System.out.println(arr[arr.length-1]);
      
           
    }
}
