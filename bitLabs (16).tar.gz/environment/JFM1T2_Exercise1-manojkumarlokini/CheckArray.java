
import java.util.*;
public class CheckArray
{
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        int size,i,no,count=0;
        System.out.println("enter size::");
        size=s.nextInt();
        int a[]=new int[size];
        System.out.println("enter array elements::");
        for(i=0;i<size;i++)
        {
            a[i]=s.nextInt();
        }
        System.out.println("enter no::");
        no=s.nextInt();
        for(i=0;i<size;i++)
        {
            if(a[i]==no)
            {
                count++;
            }
        }
        
        if(count>0)
        {
            System.out.println("element found...."+count + "times");
        }
        else
        {
            System.out.println("element not found....");
        }
    }
}