// Write a program to print your name
import java.util.Scanner;
public class Sample1 {

	public static void main(String args[]) {

	System.out.println("my name is Manoj");
	}
}