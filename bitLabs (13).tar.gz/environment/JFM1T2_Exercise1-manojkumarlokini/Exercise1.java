// Write a program to print your Name, Father's Name and Mailing Address in different lines
class Exercise1 
{
public static void main(String args[])
{
    System.out.println("my name is Manoj");
    System.out.println("my father's name is Ramu");
    System.out.println("my mailing address is manojkumarlokini@gmail.com");
    
}
}